#ifndef __RTC_H
#define __RTC_H
#include "stm32f10x.h"
#include "time.h"



void RTC_Configuration(void);
void Update_Sec(time_t tm);

#endif
