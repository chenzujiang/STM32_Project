#include "my_include.h"


time_t UNIX_Sec;
SYS_TM Sys_time;

static void RTC_NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	
	NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 5;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}

void RTC_Configuration(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP , ENABLE);
	PWR_BackupAccessCmd(ENABLE);
	RTC_EnterConfigMode();
	RCC_LSEConfig(RCC_LSE_ON);
	while(RESET == RCC_GetFlagStatus(RCC_FLAG_LSERDY));
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
	RCC_RTCCLKCmd(ENABLE);
	RTC_WaitForSynchro();
	RTC_WaitForLastTask();
	RTC_SetPrescaler(32767);
	RTC_WaitForLastTask();
	RTC_ITConfig(RTC_IT_SEC,ENABLE);
	RTC_WaitForLastTask();
	RTC_NVIC_Configuration();
	
	Sys_time.tm_year = 2014 - 1900;
	Sys_time.tm_mon = 11 - 1;
	Sys_time.tm_mday = 17;
	Sys_time.tm_hour = 11;
	Sys_time.tm_min = 32;
	Sys_time.tm_sec = 0;
	RTC_SetCounter(mktime(&Sys_time));
	RTC_WaitForLastTask();
	
	RTC_ExitConfigMode();
	PWR_BackupAccessCmd(DISABLE);
}

void Update_Sec(time_t tm)
{
	UNIX_Sec = tm;
}

time_t time(time_t * tm/*timer*/)
{
	if(tm != NULL)
		*tm = UNIX_Sec;
	return UNIX_Sec;
}


